﻿using System;
namespace Abstract_Classes_Interfaces_Properties_events
{
    public interface IMatNo
    {
        uint getMatNo();
    }
}

