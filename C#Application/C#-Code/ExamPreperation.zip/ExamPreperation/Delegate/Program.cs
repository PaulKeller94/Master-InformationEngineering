﻿namespace Delegate
{

    // see Further Examples!!
}